Java version:

openjdk version "11.0.10" 2021-01-19
OpenJDK Runtime Environment (build 11.0.10+9-post-Debian-1)
OpenJDK 64-Bit Server VM (build 11.0.10+9-post-Debian-1, mixed mode, sharing)

IDE: none - Sublime Text 3 used for development

Main Driver File: PolynomialEvaluator.java
Commane Line Usage: $ java PolynomialEvaluator <input_file>

The main driver takes input polynmoial equations in standard form (i.e. 1x1y1z1+...) 
	and evaluates them against against stored values of x,y,z. This only takes a max

Code output sent to output.txt

Debug lines are commented out with "///"

Files Included:
LinkedList.class
LinkedList.java
ListNode.class
ListNode.java
output.txt.RequiredEvaluationInput.txt
output.txt.RequiredPolynomialInput.txt
PolynomialCalculator.class
PolynomialCalculator.java
PolynomialEvaluator.class
PolynomialEvaluator.java
README.txt
RequiredEvaluationInput.txt
RequiredPolynomialInput.txt
Lab3_WriteUp_NFoster.pdf