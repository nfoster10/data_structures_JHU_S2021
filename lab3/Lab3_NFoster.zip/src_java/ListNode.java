public class ListNode
{
	public ListNode next;
	public Object data;

	ListNode(Object inputData)
	{
		data = inputData;
		next = null;
	}
}