Java version:

openjdk version "11.0.10" 2021-01-19
OpenJDK Runtime Environment (build 11.0.10+9-post-Debian-1)
OpenJDK 64-Bit Server VM (build 11.0.10+9-post-Debian-1, mixed mode, sharing)

IDE: none - Sublime Text 3 used for development

Main Driver File: ConvertPrefixToPostfix.java
Commane Line Usage: $ java ConvertPrefixToPostfix <input_file>

main driver file has been updated to now use a recursive fxn and the old algorithm has been commented out.

Code output sent to output.txt

Debug lines are commented out with "///"

Files Included:
ConvertPrefixToPostfix.class
ConvertPrefixToPostfix.java
Lab
output.txt.Required_Input
output.txt.user_input
PrefixToPostfixConverter.class
PrefixToPostfixConverter.java
Required_Input.txt
Stack.class
Stack_I.class
Stack_I.java
Stack.java
user_input.txt
                                                          